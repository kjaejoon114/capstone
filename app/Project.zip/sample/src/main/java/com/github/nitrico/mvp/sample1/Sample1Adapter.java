package com.github.nitrico.mvp.sample1;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import com.github.nitrico.mapviewpager.MapViewPager;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;

public class Sample1Adapter extends MapViewPager.Adapter {

    public static final String[] TITLES = { "E8-1 공학관", "개신문화관", "중앙도서관", "대운동장", "학연산" };

    public static final CameraPosition[] POSITIONS = {
            CameraPosition.fromLatLngZoom(new LatLng(36.62668,127.45824), 15),
            CameraPosition.fromLatLngZoom(new LatLng(36.62813,127.45929), 15),
            CameraPosition.fromLatLngZoom(new LatLng(36.62826,127.45769), 15),
            CameraPosition.fromLatLngZoom(new LatLng(36.62541,127.46209), 15),
            CameraPosition.fromLatLngZoom(new LatLng(36.62515,127.45722), 15)
    };

    public Sample1Adapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public int getCount() {
        return TITLES.length;
    }

    @Override
    public Fragment getItem(int position) {
        return Sample1Fragment.newInstance(position);
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return TITLES[position];
    }

    @Override
    public CameraPosition getCameraPosition(int position) {
        return POSITIONS[position];
    }

}
